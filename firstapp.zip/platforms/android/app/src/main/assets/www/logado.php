<!DOCTYPE html>
<html lang=en>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <title>Só de Cenoura Garçom</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="icons/material.css">
    <link rel="stylesheet" href="css/materialize.min.css">
</head>
<body>
	<h1>Logado com Sucesso!</h1>
	
    <script src="js/jquery.min.js"></script>
    <script src="js/materialize.min.js"></script>
</body>
</html>
